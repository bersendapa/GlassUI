package com.glasslayer.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("glass", Context.MODE_PRIVATE)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(56), dp(24), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#7F5AF0"), Color.parseColor("#2CB1BC"), Color.parseColor("#F25F4C"))
            )
        }

        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE); setPadding(0, dp(16), 0, dp(4))
        }

        root.addView(label("GlassLayer", 32f))
        val blurOk = getSystemService(WindowManager::class.java).isCrossWindowBlurEnabled
        root.addView(label(if (blurOk) "Window blur: supported" else "Window blur: OFF on this device (check battery saver / developer options)", 13f))

        root.addView(Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })

        root.addView(label("Blur strength"))
        root.addView(SeekBar(this).apply {
            max = 150; progress = prefs.getInt("blur", 80)
            setOnSeekBarChangeListener(listener("blur"))
        })

        root.addView(label("Glass tint"))
        root.addView(SeekBar(this).apply {
            max = 60; progress = prefs.getInt("tint", 25)
            setOnSeekBarChangeListener(listener("tint"))
        })

        root.addView(Switch(this).apply {
            text = "Frosted status bar strip"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("strip", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("strip", c).apply(); refresh() }
        })

        root.addView(Button(this).apply {
            text = "2. Start glass"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startForegroundService(Intent(this@MainActivity, GlassService::class.java))
            }
        })
        root.addView(Button(this).apply {
            text = "Stop glass"
            setOnClickListener { stopService(Intent(this@MainActivity, GlassService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun listener(key: String) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {}
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            prefs.edit().putInt(key, s.progress).apply(); refresh()
        }
    }

    private fun refresh() {
        if (prefs.getBoolean("running", false) && Settings.canDrawOverlays(this))
            startForegroundService(Intent(this, GlassService::class.java))
    }
}
