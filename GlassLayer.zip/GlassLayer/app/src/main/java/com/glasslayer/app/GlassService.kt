package com.glasslayer.app

import android.app.Dialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

class GlassService : Service() {

    private var panel: Dialog? = null
    private var strip: Dialog? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        getSharedPreferences("glass", MODE_PRIVATE).edit().putBoolean("running", true).apply()
        rebuild()
        return START_STICKY
    }

    override fun onDestroy() {
        dismissAll()
        getSharedPreferences("glass", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("glass", "GlassLayer", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "glass")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("GlassLayer is running")
            .build()
        startForeground(1, n)
    }

    private fun dismissAll() {
        panel?.dismiss(); panel = null
        strip?.dismiss(); strip = null
    }

    private fun rebuild() {
        dismissAll()
        val p = getSharedPreferences("glass", MODE_PRIVATE)
        val blur = p.getInt("blur", 80)
        val tint = p.getInt("tint", 25)
        panel = buildPanel(blur, tint)
        if (p.getBoolean("strip", true)) strip = buildStrip(blur, tint)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Liquid-glass look: soft gradient fill + bright rim. The window blur follows the corner radius. */
    private fun glass(tint: Int, radiusDp: Int): Drawable {
        val a = tint * 255 / 100
        val top = Color.argb((a * 1.6f).toInt().coerceAtMost(255), 255, 255, 255)
        val bottom = Color.argb((a * 0.6f).toInt(), 255, 255, 255)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), Color.argb(150, 255, 255, 255))
        }
    }

    private fun newDialog(bg: Drawable, blur: Int): Dialog {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
        return Dialog(ctx).apply {
            window!!.apply {
                setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
                setBackgroundDrawable(bg)
                addFlags(
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                )
                clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setBackgroundBlurRadius(blur)
            }
        }
    }

    private fun buildPanel(blur: Int, tint: Int): Dialog {
        val d = newDialog(glass(tint, 32), blur)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }
        content.addView(TextClock(this).apply {
            format12Hour = "hh:mm"; format24Hour = "HH:mm"
            textSize = 44f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 2f, Color.argb(90, 0, 0, 0))
        })
        content.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 15f
            setTextColor(Color.argb(230, 255, 255, 255))
        })
        content.addView(TextView(this).apply {
            text = "Open GlassLayer"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, 0)
            setOnClickListener {
                startActivity(
                    Intent(this@GlassService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        })

        d.setContentView(content)
        val w = d.window!!
        w.setLayout(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setGravity(Gravity.TOP or Gravity.START)
        val attrs = w.attributes
        attrs.x = dp(40); attrs.y = dp(160)
        w.attributes = attrs

        // drag to move
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        content.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = attrs.x; startY = attrs.y
                }
                MotionEvent.ACTION_MOVE -> {
                    attrs.x = startX + (e.rawX - downX).toInt()
                    attrs.y = startY + (e.rawY - downY).toInt()
                    w.attributes = attrs
                }
            }
            false
        }
        d.show()
        return d
    }

    private fun buildStrip(blur: Int, tint: Int): Dialog {
        val d = newDialog(glass(tint, 0).also { (it as GradientDrawable).setStroke(0, 0) }, blur)
        d.setContentView(View(this))
        val w = d.window!!
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val h = if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
        w.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, h)
        w.setGravity(Gravity.TOP)
        d.show()
        return d
    }
}
