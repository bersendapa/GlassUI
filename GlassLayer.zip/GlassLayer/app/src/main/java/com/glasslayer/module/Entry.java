package com.glasslayer.module;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.lang.reflect.Method;
import java.util.Set;

/**
 * GlassLayer module v0.2 for SystemUI on Android 13 (LineageOS 20).
 * v0.2 hooks methods by name only (any signature) and logs what it finds,
 * so a missing method no longer breaks the rest.
 */
public class Entry implements IXposedHookLoadPackage {

    // Tweak these and rebuild for a different look.
    private static final float BLUR_SCALE = 1.6f;    // 1.0 = stock blur strength
    private static final float ALPHA_FACTOR = 0.65f; // 1.0 = stock scrim opacity, lower = more see-through

    private static int applyCalls = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        XposedBridge.log("GlassLayer v0.2: loaded into SystemUI");
        hookBlur(lpparam.classLoader);
        hookScrims(lpparam.classLoader);
    }

    private void hookBlur(ClassLoader cl) {
        Class<?> c;
        try {
            c = XposedHelpers.findClass("com.android.systemui.statusbar.BlurUtils", cl);
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: BlurUtils not found: " + t);
            return;
        }

        // list every method name so I can see what this ROM really has
        try {
            StringBuilder sb = new StringBuilder("GlassLayer: BlurUtils methods:");
            for (Method m : c.getDeclaredMethods()) sb.append(' ').append(m.getName());
            XposedBridge.log(sb.toString());
        } catch (Throwable ignored) { }

        // 1) force "blur supported" = true
        try {
            Set<XC_MethodHook.Unhook> s = XposedBridge.hookAllMethods(c, "supportsBlursOnWindows",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(Boolean.TRUE);
                    }
                });
            XposedBridge.log("GlassLayer: supportsBlursOnWindows hooks=" + (s == null ? 0 : s.size()));
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: supportsBlursOnWindows FAILED: " + t);
        }

        // 2) make the blur radius stronger right where SystemUI applies it
        try {
            Set<XC_MethodHook.Unhook> s = XposedBridge.hookAllMethods(c, "applyBlur",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        Object[] a = param.args;
                        if (a != null && a.length >= 2 && a[1] instanceof Integer) {
                            int r = (Integer) a[1];
                            if (applyCalls < 6) {
                                applyCalls++;
                                XposedBridge.log("GlassLayer: applyBlur radius=" + r);
                            }
                            a[1] = Math.round(r * BLUR_SCALE);
                        }
                    }
                });
            XposedBridge.log("GlassLayer: applyBlur hooks=" + (s == null ? 0 : s.size()));
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: applyBlur FAILED: " + t);
        }
    }

    private void hookScrims(ClassLoader cl) {
        Class<?> c = null;
        String[] names = {
            "com.android.systemui.scrim.ScrimView",
            "com.android.systemui.statusbar.ScrimView"
        };
        for (String n : names) {
            try {
                c = XposedHelpers.findClass(n, cl);
                break;
            } catch (Throwable ignored) { }
        }
        if (c == null) {
            XposedBridge.log("GlassLayer: ScrimView not found, skipping scrim hook");
            return;
        }
        try {
            StringBuilder sb = new StringBuilder("GlassLayer: ScrimView methods:");
            for (Method m : c.getDeclaredMethods()) sb.append(' ').append(m.getName());
            XposedBridge.log(sb.toString());
        } catch (Throwable ignored) { }

        try {
            Set<XC_MethodHook.Unhook> s = XposedBridge.hookAllMethods(c, "setViewAlpha",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        Object[] a = param.args;
                        if (a != null && a.length >= 1 && a[0] instanceof Float) {
                            a[0] = ((Float) a[0]) * ALPHA_FACTOR;
                        }
                    }
                });
            XposedBridge.log("GlassLayer: setViewAlpha hooks=" + (s == null ? 0 : s.size()));
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: setViewAlpha FAILED: " + t);
        }
    }
}
