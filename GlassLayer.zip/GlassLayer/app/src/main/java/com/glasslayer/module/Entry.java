package com.glasslayer.module;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * GlassLayer module v0.1 for SystemUI on Android 13.
 * 1) forces the shade's window-blur on and makes it stronger
 * 2) makes the shade scrims more see-through so the blur shows
 * Every hook is wrapped separately: if one fails on your ROM, the others still run
 * and the reason is written to the Xposed log.
 */
public class Entry implements IXposedHookLoadPackage {

    // Tweak these two numbers and rebuild if you want a different look.
    private static final float BLUR_SCALE = 1.6f;   // 1.0 = stock blur strength
    private static final float ALPHA_FACTOR = 0.65f; // 1.0 = stock scrim opacity, lower = more see-through

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        XposedBridge.log("GlassLayer: loaded into SystemUI");
        hookBlurSupport(lpparam.classLoader);
        hookBlurStrength(lpparam.classLoader);
        hookScrims(lpparam.classLoader);
    }

    private void hookBlurSupport(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass("com.android.systemui.statusbar.BlurUtils", cl);
            XposedHelpers.findAndHookMethod(c, "supportsBlursOnWindows", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult(Boolean.TRUE);
                }
            });
            XposedBridge.log("GlassLayer: blur support hook OK");
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: blur support hook FAILED: " + t);
        }
    }

    private void hookBlurStrength(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass("com.android.systemui.statusbar.BlurUtils", cl);
            XposedHelpers.findAndHookMethod(c, "getMaxBlurRadius", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object r = param.getResult();
                    if (r instanceof Integer) {
                        param.setResult(Math.round(((Integer) r) * BLUR_SCALE));
                    }
                }
            });
            XposedBridge.log("GlassLayer: blur strength hook OK");
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: blur strength hook FAILED: " + t);
        }
    }

    private void hookScrims(ClassLoader cl) {
        Class<?> c = null;
        String[] names = {
            "com.android.systemui.scrim.ScrimView",
            "com.android.systemui.statusbar.ScrimView"
        };
        for (String n : names) {
            try {
                c = XposedHelpers.findClass(n, cl);
                break;
            } catch (Throwable ignored) { }
        }
        if (c == null) {
            XposedBridge.log("GlassLayer: ScrimView not found, skipping scrim hook");
            return;
        }
        try {
            // make the scrim see-through when drawn...
            XposedHelpers.findAndHookMethod(c, "setViewAlpha", float.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    float a = (Float) param.args[0];
                    param.args[0] = a * ALPHA_FACTOR;
                }
            });
            // ...but report the original value back so SystemUI's own animations stay consistent
            XposedHelpers.findAndHookMethod(c, "getViewAlpha", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object r = param.getResult();
                    if (r instanceof Float) {
                        param.setResult(Math.min(1f, ((Float) r) / ALPHA_FACTOR));
                    }
                }
            });
            XposedBridge.log("GlassLayer: scrim hooks OK");
        } catch (Throwable t) {
            XposedBridge.log("GlassLayer: scrim hooks FAILED: " + t);
        }
    }
}
