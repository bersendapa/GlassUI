plugins {
    id("com.android.application")
}

android {
    namespace = "com.glasslayer.module"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.glasslayer.module"
        minSdk = 31
        targetSdk = 33
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly(project(":stubs"))
}
