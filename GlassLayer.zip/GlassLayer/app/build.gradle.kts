plugins {
    id("com.android.application")
}

android {
    namespace = "com.glasslayer.module"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.glasslayer.module"
        minSdk = 31
        targetSdk = 33
        versionCode = 2
        versionName = "0.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly(project(":stubs"))
}
