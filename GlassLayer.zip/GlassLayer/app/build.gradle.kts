plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.glasslayer.app"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.glasslayer.app"
        minSdk = 31          // window blur needs Android 12+, so Android 13 is fine
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
